const { getBuffer } = require("../../lib/myfunc");

module.exports = {
  name: "cosplayvideo",
  alias: ["cv","cosplayamv","cosplayvid" ],
  desc: "To get a random cosplayvideo",
  category: "Weeb",
  usage: `cosplayamv`,
  react: "😉",
  start: async (Miku, m, { prefix }) => {
    var VID = await getBuffer(`https://nekopai-cosplayvideo-api.onrender.com/`);
    /*var Button = [
      {
        buttonId: `${prefix}cv`,
        buttonText: { displayText: `>>` },
        type: 1,
      },
    ];*/
    let bmffg = {
      video: VID,
      gifPlayback:true,
      caption: `Cosplayvideo API by *Team Atlas*\n`,
      /*footer: `*${botName}*`,
      buttons: Button,
      headerType: 4,*/
    };
    await Miku.sendMessage(m.from, bmffg, { quoted: m }).catch((err) => {
      return "Error!";
    });
  },
};
